/* KELO-INDEX
 * area: INSTANCE
 * keys: INSTANCE SCENE ZONE AUTHORITY LIFECYCLE JOIN LEAVE SNAPSHOT RECOVERY
 * hace: manager genérico de instancias offline con autoridad reemplazable, lifecycle, escena activa y aislamiento de errores
 * online: installAuthorityAdapter sustituye LocalInstanceAuthority por ServerInstanceAuthority sin cambiar la API pública
 */
(function(){
  'use strict';
  const VERSION='instance-system-v1.0.0';
  const STATUS=Object.freeze({CREATING:'CREATING',LOADING:'LOADING',ACTIVE:'ACTIVE',IDLE:'IDLE',SHUTTING_DOWN:'SHUTTING_DOWN',DESTROYED:'DESTROYED'});
  const types=new Map();
  const instances=new Map();
  const listeners=new Set();
  const idleTimers=new Map();
  const errors=[];
  let currentInstanceId=null;
  let worldReturn=null;
  let authorityAdapter=null;
  let revision=0;
  const clone=v=>v==null?v:JSON.parse(JSON.stringify(v));
  const now=()=>Date.now();
  const playerId=()=>String(window.keloNet?.playerKey||window.KELO_PROPERTY_SYSTEM?.playerId?.()||window.localPlayer?.id||'local_pioneer');
  const instanceIdFor=(type,resourceId)=>`instance:${String(type)}:${String(resourceId)}`;
  function emit(reason,instance){
    revision++;
    const payload={reason,revision,currentInstanceId,instance:instance?publicInstance(instance):null};
    listeners.forEach(fn=>{try{fn(payload);}catch(err){console.warn('[Kelo instances] listener failed',err);}});
  }
  function recordError(scope,err,instance){
    const rec={at:now(),scope,message:String(err&&err.message||err),instanceId:instance?.instanceId||currentInstanceId||null};
    errors.push(rec);if(errors.length>20)errors.shift();
    console.error('[Kelo instances]',scope,err);
    window.KELO_INSTANCE_AUDIT.lastError=rec;
    emit('error',instance||null);
    return rec;
  }
  function publicInstance(inst){
    if(!inst)return null;
    return clone({
      instanceId:inst.instanceId,type:inst.type,resourceId:inst.resourceId,ownerId:inst.ownerId,status:inst.status,revision:inst.revision,
      createdAt:inst.createdAt,lastActiveAt:inst.lastActiveAt,authoritySource:inst.authoritySource,
      config:inst.config,runtimeState:inst.runtimeState,participants:Array.from(inst.participants.values()).map(clone),lastError:inst.lastError||null
    });
  }
  function requireType(type){const h=types.get(String(type));if(!h)throw new Error('INSTANCE_TYPE_NOT_REGISTERED');return h;}
  function requireInstance(id){const inst=instances.get(String(id));if(!inst)throw new Error('INSTANCE_NOT_FOUND');return inst;}
  function clearIdleTimer(id){const t=idleTimers.get(id);if(t){clearTimeout(t);idleTimers.delete(id);}}
  function registerType(type,handler){
    type=String(type||'').trim();if(!type)throw new Error('INVALID_INSTANCE_TYPE');if(!handler||typeof handler!=='object')throw new Error('INVALID_INSTANCE_HANDLER');
    if(types.has(type))throw new Error('INSTANCE_TYPE_ALREADY_REGISTERED');types.set(type,handler);emit('type-registered',null);return type;
  }
  async function localCreate(spec){
    spec=spec||{};const type=String(spec.type||''),resourceId=String(spec.resourceId||'');if(!type||!resourceId)throw new Error('INVALID_INSTANCE_SPEC');
    const handler=requireType(type),iid=String(spec.instanceId||instanceIdFor(type,resourceId));
    const existing=instances.get(iid);if(existing&&existing.status!==STATUS.DESTROYED)return publicInstance(existing);
    const base={instanceId:iid,type,resourceId,ownerId:String(spec.ownerId||''),status:STATUS.CREATING,revision:0,createdAt:now(),lastActiveAt:now(),participants:new Map(),runtimeState:{},config:clone(spec.config||{}),authoritySource:'local-fallback',lastError:null};
    instances.set(iid,base);emit('creating',base);
    try{
      base.status=STATUS.LOADING;emit('loading',base);
      const loaded=typeof handler.create==='function'?await handler.create(clone(spec),base):null;
      if(loaded&&typeof loaded==='object'){
        if(loaded.ownerId!=null)base.ownerId=String(loaded.ownerId);
        if(loaded.revision!=null)base.revision=Math.max(0,Number(loaded.revision)||0);
        if(loaded.config)base.config=clone(loaded.config);
        if(loaded.runtimeState)base.runtimeState=clone(loaded.runtimeState);
        if(loaded.authoritySource)base.authoritySource=String(loaded.authoritySource);
      }
      base.status=STATUS.ACTIVE;base.lastActiveAt=now();emit('created',base);return publicInstance(base);
    }catch(err){base.lastError=String(err&&err.message||err);base.status=STATUS.DESTROYED;recordError('create',err,base);instances.delete(iid);throw err;}
  }
  async function localGetOrCreate(spec){const iid=String(spec?.instanceId||instanceIdFor(spec?.type,spec?.resourceId));const x=instances.get(iid);return x&&x.status!==STATUS.DESTROYED?publicInstance(x):localCreate(spec);}
  async function localJoin(data){
    const inst=requireInstance(data.instanceId),handler=requireType(inst.type);clearIdleTimer(inst.instanceId);
    const participantId=String(data.participantId||playerId()),max=Math.max(1,Math.floor(Number(inst.config?.maxPlayers)||8));
    if(!inst.participants.has(participantId)&&inst.participants.size>=max)throw new Error('INSTANCE_FULL');
    const previous=inst.participants.get(participantId)||null;
    const participant={playerId:participantId,role:String(data.role||previous?.role||'visitor'),joinedAt:previous?.joinedAt||now(),meta:clone(data.meta||previous?.meta||{})};
    try{
      if(typeof handler.onJoin==='function')await handler.onJoin(inst,clone(participant),clone(data));
      inst.participants.set(participantId,participant);inst.status=STATUS.ACTIVE;inst.lastActiveAt=now();inst.revision++;emit('join',inst);return publicInstance(inst);
    }catch(err){
      if(previous)inst.participants.set(participantId,previous);else inst.participants.delete(participantId);
      throw err;
    }
  }
  async function localLeave(data){
    const inst=requireInstance(data.instanceId),handler=requireType(inst.type),participantId=String(data.participantId||playerId());
    const participant=inst.participants.get(participantId)||null;
    if(participant&&typeof handler.onLeave==='function')await handler.onLeave(inst,clone(participant),clone(data));
    inst.participants.delete(participantId);inst.lastActiveAt=now();inst.revision++;
    if(inst.participants.size===0){
      inst.status=STATUS.IDLE;emit('idle',inst);
      const ms=Math.max(0,Math.floor(Number(inst.config?.idleDestroyMs)||0));
      if(ms===0)await localDestroy({instanceId:inst.instanceId,force:true,reason:'idle-empty'});
      else idleTimers.set(inst.instanceId,setTimeout(()=>{localDestroy({instanceId:inst.instanceId,force:true,reason:'idle-timeout'}).catch(err=>recordError('idle-destroy',err,inst));},ms));
    }else emit('leave',inst);
    return publicInstance(inst);
  }
  async function localDestroy(data){
    const inst=requireInstance(data.instanceId),handler=requireType(inst.type);if(inst.participants.size&&!data.force)throw new Error('INSTANCE_NOT_EMPTY');clearIdleTimer(inst.instanceId);
    inst.status=STATUS.SHUTTING_DOWN;emit('shutting-down',inst);
    try{if(typeof handler.serialize==='function')await handler.serialize(inst,{reason:data.reason||'destroy'});if(typeof handler.destroy==='function')await handler.destroy(inst,{reason:data.reason||'destroy'});}catch(err){inst.lastError=String(err&&err.message||err);recordError('destroy',err,inst);}
    inst.status=STATUS.DESTROYED;inst.lastActiveAt=now();emit('destroyed',inst);instances.delete(inst.instanceId);if(currentInstanceId===inst.instanceId)currentInstanceId=null;return publicInstance(inst);
  }
  function captureWorldReturn(){
    if(worldReturn)return;
    worldReturn={player:null,camera:null};
    if(typeof localPlayer!=='undefined'&&localPlayer)worldReturn.player={x:localPlayer.x,y:localPlayer.y,vx:localPlayer.vx||0,vy:localPlayer.vy||0};
    if(typeof camera!=='undefined'&&camera)worldReturn.camera={x:camera.x,y:camera.y,targetX:camera.targetX,targetY:camera.targetY,lookOffsetX:camera.lookOffsetX||0,lookOffsetY:camera.lookOffsetY||0};
  }
  function restoreWorldReturn(){
    if(!worldReturn)return;
    if(worldReturn.player&&typeof localPlayer!=='undefined'&&localPlayer)Object.assign(localPlayer,worldReturn.player);
    if(worldReturn.camera&&typeof camera!=='undefined'&&camera)Object.assign(camera,worldReturn.camera);
    worldReturn=null;
  }
  async function localEnter(data){
    const type=String(data.type||''),resourceId=String(data.resourceId||'');if(!type||!resourceId)throw new Error('INVALID_INSTANCE_SPEC');
    const actorId=String(data.participantId||playerId());
    if(currentInstanceId){
      const current=instances.get(currentInstanceId);
      if(current&&current.type===type&&current.resourceId===resourceId){await localJoin({instanceId:current.instanceId,participantId:actorId,role:data.role||'visitor',meta:data.meta||{}});return publicInstance(current);}
      await localLeaveCurrent({participantId:actorId,preserveWorldReturn:true});
    }
    captureWorldReturn();
    const created=await localGetOrCreate({type,resourceId,instanceId:data.instanceId,ownerId:data.ownerId,config:data.config,meta:data.meta});
    const inst=requireInstance(created.instanceId);await localJoin({instanceId:inst.instanceId,participantId:actorId,role:data.role||'visitor',meta:data.meta||{}});currentInstanceId=inst.instanceId;
    const handler=requireType(inst.type);if(typeof handler.onEnterLocal==='function')await handler.onEnterLocal(inst,{participantId:actorId,meta:clone(data.meta||{})});
    emit('entered',inst);return publicInstance(inst);
  }
  async function localLeaveCurrent(data){
    if(!currentInstanceId)return null;const inst=instances.get(currentInstanceId);if(!inst){currentInstanceId=null;restoreWorldReturn();return null;}
    const actorId=String(data?.participantId||playerId()),handler=requireType(inst.type);
    try{if(typeof handler.beforeLeaveLocal==='function')await handler.beforeLeaveLocal(inst,{participantId:actorId,reason:data?.reason||'leave'});}catch(err){recordError('before-leave-local',err,inst);}
    currentInstanceId=null;
    try{await localLeave({instanceId:inst.instanceId,participantId:actorId,reason:data?.reason||'leave'});}catch(err){recordError('leave-current',err,inst);}
    if(typeof handler.afterLeaveLocal==='function'){try{await handler.afterLeaveLocal(inst,{participantId:actorId,reason:data?.reason||'leave'});}catch(err){recordError('after-leave-local',err,inst);}}
    if(!data?.preserveWorldReturn)restoreWorldReturn();emit('returned-world',inst);return publicInstance(inst);
  }
  const LocalInstanceAuthority=Object.freeze({source:'local-fallback',request:async function(op,payload){
    if(op==='instance:create')return localCreate(payload);
    if(op==='instance:getOrCreate')return localGetOrCreate(payload);
    if(op==='instance:join')return localJoin(payload);
    if(op==='instance:leave')return localLeave(payload);
    if(op==='instance:destroy')return localDestroy(payload);
    if(op==='instance:enter')return localEnter(payload);
    if(op==='instance:leaveCurrent')return localLeaveCurrent(payload||{});
    if(op==='instance:list')return Array.from(instances.values()).map(publicInstance);
    throw new Error('UNKNOWN_INSTANCE_OPERATION');
  }});
  async function request(op,payload){const adapter=authorityAdapter||LocalInstanceAuthority;return adapter.request(op,payload||{});}
  function installAuthorityAdapter(adapter){if(adapter&&typeof adapter.request!=='function')throw new Error('INVALID_INSTANCE_AUTHORITY_ADAPTER');authorityAdapter=adapter||null;window.KELO_INSTANCE_AUDIT.authority=adapter?'remote-adapter':'local-fallback';emit('authority-changed',null);}
  function ingestAuthoritySnapshot(input){
    const rows=Array.isArray(input?.instances)?input.instances:[];
    for(const raw of rows){if(!raw?.instanceId||!raw?.type||!raw?.resourceId)continue;const inst={instanceId:String(raw.instanceId),type:String(raw.type),resourceId:String(raw.resourceId),ownerId:String(raw.ownerId||''),status:String(raw.status||STATUS.ACTIVE),revision:Number(raw.revision)||0,createdAt:Number(raw.createdAt)||now(),lastActiveAt:Number(raw.lastActiveAt)||now(),participants:new Map((raw.participants||[]).map(p=>[String(p.playerId),clone(p)])),runtimeState:clone(raw.runtimeState||{}),config:clone(raw.config||{}),authoritySource:'server',lastError:raw.lastError||null};instances.set(inst.instanceId,inst);}
    if(input?.currentInstanceId)currentInstanceId=String(input.currentInstanceId);emit('authority-snapshot',currentInstanceId?instances.get(currentInstanceId):null);return getActiveInstances();
  }
  function current(){return currentInstanceId?publicInstance(instances.get(currentInstanceId)):null;}
  function getActiveInstances(){return Array.from(instances.values()).filter(x=>x.status!==STATUS.DESTROYED).map(publicInstance);}
  function isInstanceActive(type){const c=current();return !!c&&(!type||c.type===type);}
  // KELO-INDEX INSTANCE/SNAPSHOT sincroniza runtime local tras una mutación de la autoridad de tipo. En online llega por ingestAuthoritySnapshot.
  function syncRuntime(instanceId,patch,nextRevision){const inst=requireInstance(instanceId);if(patch&&typeof patch==='object')inst.runtimeState=Object.assign({},inst.runtimeState||{},clone(patch));if(nextRevision!=null)inst.revision=Math.max(Number(inst.revision)||0,Number(nextRevision)||0);inst.lastActiveAt=now();emit('runtime-synced',inst);return publicInstance(inst);}
  function renderActiveScene(g,stage){const inst=currentInstanceId&&instances.get(currentInstanceId);if(!inst)return false;const h=types.get(inst.type);if(!h||typeof h.render!=='function')return false;try{h.render(g,stage||'background',inst);return true;}catch(err){inst.lastError=String(err&&err.message||err);recordError('render',err,inst);return true;}}
  function updateActive(dt){const inst=currentInstanceId&&instances.get(currentInstanceId);if(!inst)return false;const h=types.get(inst.type);try{if(h&&typeof h.update==='function')h.update(Number(dt)||0,inst);return true;}catch(err){inst.lastError=String(err&&err.message||err);recordError('update',err,inst);return true;}}
  async function serializeInstance(id){const inst=requireInstance(id),h=requireType(inst.type);return typeof h.serialize==='function'?h.serialize(inst,{reason:'manual'}):publicInstance(inst);}
  function onChange(fn){if(typeof fn!=='function')return()=>{};listeners.add(fn);return()=>listeners.delete(fn);}
  window.KELO_INSTANCES=Object.freeze({
    version:VERSION,STATUS,registerType,request,installAuthorityAdapter,ingestAuthoritySnapshot,
    createInstance:spec=>request('instance:create',spec),getInstance:id=>publicInstance(instances.get(String(id))),getOrCreateInstance:spec=>request('instance:getOrCreate',spec),
    joinInstance:(id,payload)=>request('instance:join',Object.assign({},payload||{},{instanceId:id})),leaveInstance:(id,payload)=>request('instance:leave',Object.assign({},payload||{},{instanceId:id})),
    destroyInstance:(id,payload)=>request('instance:destroy',Object.assign({},payload||{},{instanceId:id})),serializeInstance,getActiveInstances,
    enter:(type,resourceId,opts)=>request('instance:enter',Object.assign({},opts||{},{type,resourceId})),leaveCurrent:opts=>request('instance:leaveCurrent',opts||{}),
    current,isInstanceActive,syncRuntime,renderActiveScene,updateActive,onChange,instanceIdFor,playerId,
    get errors(){return clone(errors);},get authoritySource(){return authorityAdapter?'remote-adapter':'local-fallback';}
  });
  window.KELO_INSTANCE_AUDIT={version:VERSION,authority:'local-fallback',serverReplaceable:true,currentZone:'WORLD',activeCount:0,lastError:null};
  onChange(()=>{const c=current();window.KELO_INSTANCE_AUDIT.currentZone=c?`${c.type.toUpperCase()}_INSTANCE`:'WORLD';window.KELO_INSTANCE_AUDIT.activeCount=getActiveInstances().length;});
})();
